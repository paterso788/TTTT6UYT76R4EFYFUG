python menu.py
